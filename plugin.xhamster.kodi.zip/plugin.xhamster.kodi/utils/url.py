def url_decode(s:str) -> str:
    ''' partial impln, only enough for this specific purpose '''
    return s.replace('%20', ' ')