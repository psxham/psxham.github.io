from models.item import Item
from resolvers.xhamster import resolveShows

# def getPage(show_path: str, searchTerm: str) -> Page:
#     api_response = resolvePage(show_path)

#     raw_episodes = api_response['item']['episodes']['items']
    
#     paging = api_response['item']['episodes']['paging']

#     items = [Item(name="Back to search results", description="Back to search results", params={'path': 'landing_screen', 'searchTerm': searchTerm})]

#     items += [Item(name=i['episodeName'], description= i['shortDescription'], image=i['images']['tile'],to_play=i['offers'][0]['scopes'][0]) for i in raw_episodes]

#     page = Page(title = api_response['title'], items = items)

#     return page


# def search(searchTerm: str):
#     search_results = resolveSearch(searchTerm)

#     jsonObj = re.search("/window.initials=(.*)?;<\/script>/", search_results)

#     print(jsonObj)

#     # items += [Item(name=i['secondaryLanguageTit?e'] if 'secondaryLanguageTitle' in i else i['title'], description=i['shortDescription'], image=i['images']['tile'], params={'path':'listShowEpisodes', 'show_path': i['path'], 'searchTerm': searchTerm}) for i in tv_items]

#     page = Page(title = f'Search Results for {searchTerm}', items = items)

#     return page



def resolve_xhamster_url_to_video(url):
    video_url = resolveShows(url)

    return video_url