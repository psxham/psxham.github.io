# DAOs
import requests
import re
import json


def resolvePage(show_path: str) -> dict:
    headers = {
        'Accept': 'application/json',
        'Referer': 'https://www.xHamster.sg/',
        'sec-ch-ua-mobile': '?0',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36',
    }

    url = f'https://cdn.xHamster.sg/api/page?ff=idp%2Cldp%2Crpt%2Ccd&item_detail_expand=all&item_detail_select_season=first&lang=en&list_page_size=24&max_list_prefetch=3&path={show_path}&segments=all&sub=Anonymous&text_entry_format=html'

    response = requests.get(url, headers=headers)
    
    r = response.json()

    return r



def get_saved_videos():
    return [
        {
            "name": "Big boobies doggy self filmed",
            "url": "https://xhamster2.com/videos/sg-yan-ting-homemade-xhbwCxk"
        },
        {
            "name": "Screaming like dying chalet",
            "url": "https://xhamster2.com/videos/singaporean-girl-screaming-in-chalet-while-getting-railed-xhvrRYL"
        },
        {
            "name": "Mole on eyebrow girl",
            "url": "https://xhamster2.com/videos/sexy-ex-girlfriend-still-enjoys-my-cock-very-much-xh1mfaS&from=player_related"
        },
        {
            "name": "Ang Moh And Chinese Girl",
            "url": "https://xhamster3.com/videos/hot-chinese-pussy-get-the-long-white-dick-9286325"
        },
        {
            "name": "Girl smoker strips",
            "url": "https://xhamster3.com/videos/li-ting-s-striptease-video-xhuFZCY"
        },
        {
            "name": "Girl fingering",
            "url": "https://xhamster3.com/videos/singapore-amateur-compilation-chevonne-xhfmt0B"
        },
        {
            "name": "XMM fingers",
            "url": "https://xhamster3.com/videos/singapore-girl-webcam-ashley-xhmXmqt"
        },
        {
            "name": "Flat chested XMM riding until pants",
            "url": "https://xhamster3.com/videos/sg-chinese-cutie-xmm-gf-with-perfect-small-tits-rides-bf-s-cock-xhAsPIJ"
        },
        {
            "name": "JAV - Japanese Sister",
            "url": "https://xhamster3.com/videos/japanese-cute-sister-7665876"
        },
    ]
    # r = requests.get('http://192.168.1.110:5000/')
    # jsonObj = r.json()

    # print(jsonObj)

    # return jsonObj




def resolveSearch(searchTerm: str) -> str:
    headers = {
        'authority': 'xhamster2.com',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',
        'referer': f'https://xhamster2.com/search/{searchTerm}',
        'accept-language': 'en-US,en;q=0.9',
    }

    response = requests.get('https://xhamster2.com/search/sg', headers=headers)

    search_results = response.content

    matches = re.search("window.initials=(.*)?;<\/script>", search_results.decode())

    jsonObj = json.loads(matches.group(1))

    print(jsonObj)

    return response.content


def resolveShows(url: str) -> dict:
    headers = {
        'authority': 'xhamster2.com',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',
        'referer': f'https://xhamster2.com/',
        'accept-language': 'en-US,en;q=0.9',
    }

    r = requests.get(url, headers = headers)

    matches = re.search("window.initials=(.*)?;<\/script>", r.content.decode())

    jsonObj = json.loads(matches.group(1))

    return jsonObj['xplayerSettings']['sources']['hls']['fallback']